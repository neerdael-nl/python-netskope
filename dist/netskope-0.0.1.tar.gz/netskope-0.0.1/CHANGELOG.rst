*********
ChangeLog
*********

|   20230321    v0.0.1  Initial Class commit for privateapps class
|                       Base class attributes and ini file 
|                       handling.

