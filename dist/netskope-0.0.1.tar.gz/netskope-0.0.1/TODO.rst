=====
TO DO
=====

- add extra functions required for proof of value